<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="robots" content="noindex, nofollow">
      <title>Google Sheet Submit</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" id="bootstrap-css">
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
   </head>
   <body>
      <form method="post" action="append-sheet.php">
         <label>
            <p class="label-txt">ENTER YOUR NAME</p>
            <input type="text" class="input" name="Name" required>
            <div class="line-box">
               <div class="line"></div>
            </div>
         </label>
         <label>
            <p class="label-txt">ENTER YOUR EMAIL</p>
            <input type="text" class="input" name="Email" required>
            <div class="line-box">
               <div class="line"></div>
            </div>
         </label>

         <button type="submit">Submit</button>
      </form>
	  
   </body>
</html>