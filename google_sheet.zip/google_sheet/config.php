<?php
require_once 'vendor/autoload.php';
require_once 'class-db.php';
  
define('GOOGLE_CLIENT_ID', '692694312653-ojtapr4dc7gfbbktk6ngq3aghfenetbb.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'R3GBnmOdkgBQFxfxHsRsTrSL');
  
$config = [
    'callback' => 'http://localhost/fbphp/callback.php',
    'keys'     => [
                    'id' => GOOGLE_CLIENT_ID,
                    'secret' => GOOGLE_CLIENT_SECRET
                ],
    'scope'    => 'https://www.googleapis.com/auth/spreadsheets',
    'authorize_url_parameters' => [
            'approval_prompt' => 'force', // to pass only when you need to acquire a new refresh token.
            'access_type' => 'offline'
    ]
];
  
$adapter = new Hybridauth\Provider\Google( $config );

?>